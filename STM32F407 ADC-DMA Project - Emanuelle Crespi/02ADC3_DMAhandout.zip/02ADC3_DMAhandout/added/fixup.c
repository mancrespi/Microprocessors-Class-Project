//fixup.c wmh 2016-04-06 : attempt to disable assert_param macro by making it an empty function
void assert_param(int ignored){;} 